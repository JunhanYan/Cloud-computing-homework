package homework3;
import java.io.IOException;
import java.util.Vector;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class HomeworkIgnoreSame implements Tool{
	Configuration conf;
	public static class HomeworkMapper extends Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);
		private Text text = new Text();
		
		public void map(Object key, Text value, Context context)
				throws IOException, InterruptedException {
			String[] s = value.toString().replaceAll("[^a-zA-Z\\s]", "").trim().toLowerCase().split("\\s+");
			StringBuffer sb = new StringBuffer("");
			Vector<String> usedWords = new Vector<String>(s.length); 
			int i, j;
			for (i = 0; i < s.length; i++) {
				if(usedWords.contains(s[i]))
					continue;
				else
					usedWords.add(s[i]);
				for (j = 0; j < s.length; j++) {
					if (i != j) {
						sb.setLength(0);
						sb.append(s[i]).append("\t").append(s[j]);
						text.set(sb.toString());
						context.write(text, one);
					}
				}
			}

		}
		public int appearBefore(String[] str, int location){
			int num = 1;
			for(int i= 0 ;i<location;i++){
				if(str[location].equals(str[i])){
					num++;
				}
			}
			return num;
		}
		public String stringTool(int num){
			String str="With the word ";
			switch (num){
			case 0:break;
			case 1:{
				str="With the 2nd word ";
				break;
			}
			case 2:{
				str="With the 3rd word ";
				break;
			}
			default:{
				str="With the "+num+"th word ";
				break;
			}
			}
			return str;
		}
	}

	public static class HomeworkReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	
		private IntWritable result = new IntWritable();
		
		public void reduce(Text key, Iterable<IntWritable> values,
				Context context) throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
	
		 int ret = ToolRunner.run(new HomeworkIgnoreSame(), args);  
		    System.exit(ret);  
	}

	@Override
	public Configuration getConf() {
		// TODO Auto-generated method stub
		return conf;
	}

	@Override
	public void setConf(Configuration arg0) {
		arg0 = new Configuration();  
		conf=arg0;  
		
	}

	@Override
	public int run(String[] arg0) throws Exception {
		
		if (arg0.length != 2) {
			System.err.println("Usage: wordcount <in> <out>");
			System.exit(2);
		}
		Job job = new Job(conf, "word count");
		job.setJarByClass(HomeworkIgnoreSame.class);
		job.setMapperClass(HomeworkMapper.class);
		job.setCombinerClass(HomeworkReducer.class);
		job.setReducerClass(HomeworkReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(arg0[0]));
		FileOutputFormat.setOutputPath(job, new Path(arg0[1]));
		boolean success=  job.waitForCompletion(true);
				
		return success?0:1;
	}

}
