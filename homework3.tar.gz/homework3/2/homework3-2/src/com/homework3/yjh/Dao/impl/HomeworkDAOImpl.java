package com.homework3.yjh.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.homework3.yjh.bean.Homework;
import com.homework3.yjh.Dao.IHomeworkDAO;
import com.homework3.yjh.util.JDBC_Connection;

public class HomeworkDAOImpl implements IHomeworkDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	@Override
	public List<Homework> qryAllByOneKey(Homework h) throws Exception {
		
		 List<Homework>	l = new ArrayList<Homework>();
			String sql = "select * from homework where firstword=?";
			conn = JDBC_Connection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, h.getFirst());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Homework homework = new Homework();
				homework.setFirst(rs.getString(1));
				homework.setSecond(rs.getString(2));
				homework.setCount(rs.getInt(3));
				l.add(homework);
			}
		return l;
	}

	@Override
	public List<Homework> qryByTwoKeys(Homework h) {
		List<Homework> l = new ArrayList<Homework>();
		String sql = "select * from homework where firstword=? and secondword=?";
		try {
			conn = JDBC_Connection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, h.getFirst());
			pstmt.setString(2, h.getSecond());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Homework homework = new Homework();
				homework.setFirst(rs.getString(1));
				homework.setSecond(rs.getString(2));
				homework.setCount(rs.getInt(3));
				l.add(homework);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBC_Connection.free(rs, conn, pstmt);
		}
		return l;
	}

}
