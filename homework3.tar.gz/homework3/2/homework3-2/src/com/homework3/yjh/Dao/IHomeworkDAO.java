package com.homework3.yjh.Dao;

import java.util.List;

import com.homework3.yjh.bean.Homework;

public interface IHomeworkDAO {
	List<Homework> qryAllByOneKey(Homework h) throws Exception ;

	List<Homework> qryByTwoKeys(Homework h) throws Exception ;
}
