package com.homework3.yjh.bean;

import java.io.Serializable;

public class Homework implements Serializable {
	private static final long serialVersionUID = 1L;
	private String first;
	private String second;
	private int count;


	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getSecond() {
		return second;
	}

	public void setSecond(String second) {
		this.second = second;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
