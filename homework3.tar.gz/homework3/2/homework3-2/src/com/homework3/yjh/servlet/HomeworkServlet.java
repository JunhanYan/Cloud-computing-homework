package com.homework3.yjh.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.homework3.yjh.service.IHomeworkSvc;
import com.homework3.yjh.service.impl.HomeworkSvcImpl;
import com.homework3.yjh.bean.Homework;


public class HomeworkServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String s = request.getParameter("str");
		String[] ss = s.trim().split("\\s");
		IHomeworkSvc homeworkSvc = new HomeworkSvcImpl();
		if (ss.length == 1) {
			List<Homework> h = null;
			try {
				h = homeworkSvc.qryAllByOneKey(ss[0]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (h.size() == 0) {
				request.setAttribute("status", "fail");
			} else {
				request.setAttribute("status", "success");
				request.setAttribute("result", h);
			}
		} else if (ss.length == 2) {
			List<Homework> h = null;
			try {
				h = homeworkSvc.qryByTwoKeys(ss[0], ss[1]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (h.size() == 0) {
				request.setAttribute("status", "fail");
			} else {
				request.setAttribute("status", "success");
				request.setAttribute("result", h);
			}
		}
		request.getRequestDispatcher("index.jsp").forward(request, response) ;
	}

}
