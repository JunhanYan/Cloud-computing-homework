package com.homework3.yjh.service.impl;

import java.util.List;

import com.homework3.yjh.bean.Homework;
import com.homework3.yjh.Dao.IHomeworkDAO;
import com.homework3.yjh.Dao.impl.HomeworkDAOImpl;
import com.homework3.yjh.service.IHomeworkSvc;

public class HomeworkSvcImpl implements IHomeworkSvc {

private IHomeworkDAO homeworkDAO = new HomeworkDAOImpl();

	@Override
	public List<Homework> qryAllByOneKey(String first) throws Exception {
		Homework h = new Homework();
		h.setFirst(first);
		return homeworkDAO.qryAllByOneKey(h);
	}

	@Override
	public List<Homework> qryByTwoKeys(String first, String second) throws Exception {
		Homework h = new Homework();
		h.setFirst(first);
		h.setSecond(second);
		return homeworkDAO.qryByTwoKeys(h);
	}
}
