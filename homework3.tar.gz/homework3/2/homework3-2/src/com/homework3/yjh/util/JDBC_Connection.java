package com.homework3.yjh.util;

import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;
import java.sql.Statement;  


public class JDBC_Connection {
	
	//static String url = "jdbc:hive://127.0.0.1:10000/homework";

	
			
		
	public static Connection getConnection()  {
		  
		try {
			Class.forName("org.apache.hadoop.hive.jdbc.HiveDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection conn=null;
		try {
			conn = DriverManager.getConnection("jdbc:hive://127.0.0.1:10000/homework", "", "");
		} catch (SQLException e) {
		
			e.printStackTrace();
		}  
		       
		
		return conn;
	}

	public static void free(ResultSet rs, Connection conn, Statement stmt) {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (stmt != null) {
				stmt.close();
				stmt = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	  public static void main(String[] args) throws Exception {  
	    	
  	
  			//  Class.forName("org.apache.hadoop.hive.jdbc.HiveDriver");  
  		
  	 
    
        
      //String dropSQL="drop table javabloger";  
      //String createSQL="create table javabloger (key int, value string)";  
      //String insterSQL="LOAD DATA LOCAL INPATH '/work/hive/examples/files/kv1.txt' OVERWRITE INTO TABLE javabloger";  
      //String querySQL="SELECT a.* FROM javabloger a";  
      String querySQL="select * from homework where firstword=?";
        
      Connection con =getConnection(); //DriverManager.getConnection("jdbc:hive://127.0.0.1:10000/homework", "", "");  
     // Statement stmt = con.createStatement();  
      PreparedStatement  pstmt = con.prepareStatement(querySQL);
		pstmt.setString(1, "your");
//      stmt.executeQuery(dropSQL);  
//      stmt.executeQuery(createSQL);  
//      stmt.executeQuery(insterSQL);  
      ResultSet res = pstmt.executeQuery();  
        
      while (res.next()) {  
          System.out.println("Result: key:"+res.getString(1) +"  –>  value:" +res.getString(2));  
      }  
  }  
}
