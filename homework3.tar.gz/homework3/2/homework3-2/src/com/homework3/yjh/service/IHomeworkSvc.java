package com.homework3.yjh.service;

import java.util.List;





import com.homework3.yjh.bean.Homework;

public interface IHomeworkSvc {
	List<Homework> qryAllByOneKey(String first) throws Exception ;

	List<Homework> qryByTwoKeys(String first, String second)throws Exception ;
}
